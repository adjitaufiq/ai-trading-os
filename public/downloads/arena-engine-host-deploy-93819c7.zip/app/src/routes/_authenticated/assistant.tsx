import {
  createFileRoute,
  Link,
  Outlet,
  useNavigate,
  useParams,
  useRouterState,
} from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import {
  Plus,
  Radar,
  Trash2,
  LogOut,
  ArrowLeft,
  PanelLeft,
  ChevronDown,
  History,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTitle,
  SheetDescription,
  SheetTrigger,
} from "@/components/ui/sheet";
import { supabase } from "@/integrations/supabase/client";
import {
  createThread,
  deleteThread,
  listThreads,
  threadsQueryKey,
  type AssistantThread,
} from "@/lib/assistant/threads";
import {
  SCOPE_LABEL,
  THREAD_SCOPES,
  TOPIC_LABEL,
  type ThreadScope,
} from "@/lib/assistant/knowledgeBase";

const dayKey = (iso: string) => {
  const d = new Date(iso);
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
};

const dayFormatter = new Intl.DateTimeFormat("id-ID", {
  day: "numeric",
  month: "short",
  year: "numeric",
});

/** Header gaya history Chrome: "Hari ini - 9 Okt 2026". */
function dayLabel(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const cur = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  if (cur.getTime() === today.getTime()) return `Hari ini - ${dayFormatter.format(d)}`;
  if (cur.getTime() === yesterday.getTime()) return `Kemarin - ${dayFormatter.format(d)}`;
  return dayFormatter.format(d);
}

/** Thread dikelompokkan per hari, terbaru dulu (konsep history Chrome). */
function groupByDay(threads: AssistantThread[]): Array<[string, AssistantThread[]]> {
  const sorted = [...threads].sort(
    (a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime(),
  );
  const groups = new Map<string, AssistantThread[]>();
  for (const t of sorted) {
    const key = dayKey(t.updated_at);
    const list = groups.get(key);
    if (list) list.push(t);
    else groups.set(key, [t]);
  }
  return [...groups.entries()];
}

export const Route = createFileRoute("/_authenticated/assistant")({
  head: () => ({
    meta: [
      { title: "AI Trading Assistant — Personal AI Trading OS" },
      {
        name: "description",
        content:
          "Asisten pengetahuan Trading OS: Radar, regime, horizon, events, dan paper trading berbasis data Engine Host live.",
      },
      { property: "og:title", content: "AI Trading Assistant — Trading OS" },
      {
        property: "og:description",
        content: "Tanya kondisi Radar dan arti istilah engine, per simbol dan per topik.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AssistantLayout,
});

function AssistantLayout() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const params = useParams({ strict: false }) as { threadId?: string };
  const { data: threads = [] } = useQuery({ queryKey: threadsQueryKey, queryFn: listThreads });
  const [busy, setBusy] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const reportPage = pathname === "/assistant/control" || pathname === "/assistant/research";
  const pageTitle =
    pathname === "/assistant/control"
      ? "Kontrol"
      : pathname === "/assistant/research"
        ? "Riset"
        : "AI Trading Assistant";

  const create = async (scope: ThreadScope, topic: string) => {
    setBusy(true);
    try {
      const t = await createThread(scope, topic);
      await qc.invalidateQueries({ queryKey: threadsQueryKey });
      setMenuOpen(false);
      navigate({ to: "/assistant/$threadId", params: { threadId: t.id } });
    } finally {
      setBusy(false);
    }
  };
  const remove = async (id: string) => {
    await deleteThread(id);
    await qc.invalidateQueries({ queryKey: threadsQueryKey });
    if (params.threadId === id) navigate({ to: "/assistant" });
  };

  const [newChatOpen, setNewChatOpen] = useState(false);
  const historyGroups = useMemo(() => groupByDay(threads), [threads]);

  const newChatPanel = (
    <div className="border-b border-border pb-1">
      <button
        type="button"
        onClick={() => setNewChatOpen((v) => !v)}
        aria-expanded={newChatOpen}
        aria-label="Buat percakapan baru"
        className="flex w-full items-center justify-between rounded px-3 py-2.5 text-sm font-medium hover:bg-accent/50"
      >
        <span className="flex items-center gap-2">
          <Plus className="size-4 text-bull" /> Percakapan baru
        </span>
        <ChevronDown
          className={`size-4 text-muted-foreground transition-transform ${newChatOpen ? "rotate-180" : ""}`}
        />
      </button>
      {newChatOpen ? (
        <div className="space-y-2 px-2 pb-2">
          {(Object.keys(THREAD_SCOPES) as ThreadScope[]).map((scope) => (
            <div key={scope}>
              <p className="px-1 py-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                {SCOPE_LABEL[scope]}
              </p>
              <div className="flex flex-wrap gap-1">
                {THREAD_SCOPES[scope].map((topic) => (
                  <Button
                    variant="outline"
                    size="sm"
                    key={topic}
                    disabled={busy}
                    onClick={() => create(scope, topic)}
                    className="h-auto min-h-9 whitespace-normal px-2 py-1 text-xs text-muted-foreground"
                  >
                    {TOPIC_LABEL[topic]}
                  </Button>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );

  const navigation = (
    <>
      {newChatPanel}
      <nav aria-label="Histori percakapan" className="min-h-0 flex-1 overflow-y-auto p-3">
        <p className="flex items-center gap-1.5 px-2 pb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          <History className="size-3.5" /> Histori
        </p>
        {historyGroups.length === 0 ? (
          <p className="px-2 py-6 text-center text-xs text-muted-foreground">
            Belum ada percakapan.
          </p>
        ) : (
          historyGroups.map(([key, items]) => {
            const first = items[0];
            return (
              <section key={key} className="mb-2">
                {first ? (
                  <p className="px-2 py-1.5 text-xs font-semibold text-foreground/80">
                    {dayLabel(first.updated_at)}
                  </p>
                ) : null}
                {items.map((t) => {
                  const scope = (t.symbol ?? "KNOWLEDGE") as ThreadScope;
                  return (
                    <div
                      key={t.id}
                      className={`group flex items-center rounded ${params.threadId === t.id ? "bg-accent" : "hover:bg-accent/50"}`}
                    >
                      <span className="ml-2 shrink-0 rounded bg-secondary px-1.5 py-0.5 text-[9px] font-semibold text-secondary-foreground">
                        {SCOPE_LABEL[scope]}
                      </span>
                      <Link
                        to="/assistant/$threadId"
                        params={{ threadId: t.id }}
                        onClick={() => setMenuOpen(false)}
                        className="min-w-0 flex-1 px-2 py-2.5"
                      >
                        <p className="truncate text-sm">{t.title}</p>
                        <p className="truncate text-[10px] text-muted-foreground">
                          {TOPIC_LABEL[t.topic] ?? t.topic}
                        </p>
                      </Link>
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label={`Hapus percakapan ${t.title}`}
                        onClick={() => remove(t.id)}
                        className="shrink-0 text-muted-foreground md:opacity-0 md:group-hover:opacity-100 focus-visible:opacity-100"
                      >
                        <Trash2 className="size-3.5" />
                      </Button>
                    </div>
                  );
                })}
              </section>
            );
          })
        )}
      </nav>
      <div className="flex gap-1 border-t border-border p-2">
        <Button asChild variant="ghost" size="sm" className="flex-1">
          <Link to="/">
            <ArrowLeft className="size-4" />
            Terminal
          </Link>
        </Button>
        <Button
          variant="ghost"
          size="icon"
          aria-label="Keluar akun"
          title="Keluar akun"
          onClick={async () => {
            await supabase.auth.signOut();
            navigate({ to: "/auth" });
          }}
        >
          <LogOut className="size-4" />
        </Button>
      </div>
    </>
  );

  return (
    <div className="assistant-cockpit flex h-dvh min-h-0 flex-col overflow-hidden bg-background text-foreground">
      <header className="grid shrink-0 grid-cols-[minmax(0,1fr)_auto] items-center gap-2 border-b border-border px-3 py-3 md:px-5">
        <div className="flex min-w-0 items-center gap-2">
          {!reportPage && (
            <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="shrink-0 md:hidden"
                  aria-label="Buka percakapan"
                  title="Percakapan"
                >
                  <PanelLeft />
                </Button>
              </SheetTrigger>
              <SheetContent
                side="left"
                className="flex w-[min(90vw,22rem)] max-w-none flex-col gap-0 p-0"
              >
                <div className="border-b border-border p-4 pr-12">
                  <SheetTitle>Percakapan</SheetTitle>
                  <SheetDescription>AI Trading Assistant</SheetDescription>
                </div>
                {navigation}
              </SheetContent>
            </Sheet>
          )}
          <Radar className="hidden size-6 shrink-0 text-bull sm:block" aria-hidden />
          <div className="min-w-0">
            <h1 className="truncate text-sm font-semibold sm:text-base">{pageTitle}</h1>
            <p className="text-[10px] text-muted-foreground sm:text-xs">
              Engine Host · AI MONITOR_ONLY
            </p>
          </div>
        </div>
        {reportPage && (
          <Button asChild variant="ghost" size="sm">
            <Link to="/">
              <ArrowLeft className="size-4" />
              Terminal
            </Link>
          </Button>
        )}
      </header>
      <div className="flex min-h-0 flex-1">
        {!reportPage && (
          <aside className="hidden w-72 shrink-0 flex-col border-r border-border md:flex">
            {navigation}
          </aside>
        )}
        <main className="flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
