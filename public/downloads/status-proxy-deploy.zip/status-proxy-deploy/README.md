# Status-only proxy (Windows VPS)
Port 8782 (loopback) -> reads ONLY 127.0.0.1:8090 GET /v1/health + /v1/engine/execution-status.
Public routes: GET /v1/health, GET /v1/public/engine-status. Everything else 404, non-GET 405.
Returns only: online/offline, heartbeat, phase/stage, signal, execution/mode/MT5/Shadow enums,
fresh/stale, sanitized blocker codes, symbols XAUUSD/BTCUSD. No balance/equity/login/server/
positions/prices/volume/journal/secret. No secret, no restart of Engine Host, no order path.

## Install (PowerShell)
    Expand-Archive .\status-proxy-deploy.zip -DestinationPath C:\arena -Force
    cd C:\arena\status-proxy-deploy
    python -m unittest tests.test_status_proxy        # expect: OK (6 tests)

## Run (window 1)
    python -m status_proxy.proxy

## Local checks (window 2)
    (Invoke-WebRequest http://127.0.0.1:8782/v1/public/engine-status -UseBasicParsing).Content
    # Must be 404 (sensitive route denied):
    try { Invoke-WebRequest http://127.0.0.1:8782/v1/demo/account -UseBasicParsing } catch { $_.Exception.Response.StatusCode.value__ }
    try { Invoke-WebRequest http://127.0.0.1:8782/v1/engine/execution-status -UseBasicParsing } catch { $_.Exception.Response.StatusCode.value__ }

## Quick Tunnel (window 3) — ONLY port 8782, never 8090/8765/8100
    cloudflared tunnel --url http://127.0.0.1:8782
Send the printed https://....trycloudflare.com URL to Lovable to set VITE_ENGINE_STATUS_URL + publish.

## Rollback
Stop the cloudflared window and the proxy window (Ctrl+C), delete C:\arena\status-proxy-deploy.
Engine Host is never touched.
