# Engine Status Agent — Paket Windows/VPS

Agent read-only, outbound-only. Membaca HANYA `http://127.0.0.1:8090`
(`GET /v1/engine/health` dan `GET /v1/engine/execution-status`), menyalin field
allowlist minimal, menandatangani dengan HMAC-SHA256 memakai
`ENGINE_STATUS_AGENT_SECRET`, lalu POST via HTTPS ke relay backend setiap 15 detik.

Tidak ada port inbound, tidak ada tunnel, tidak ada write ke Engine Host,
tidak ada jalur order. Python stdlib saja (Python 3.10+).

## Field yang dikirim (hanya ini)

`engine, mode, execution, mt5, shadow, kill_switch, signal, stale, phase, stage,
blockers (kode saja), symbols (XAUUSD/BTCUSD), engine_checked_at, engine_reachable`

Tidak pernah dikirim: balance, equity, login, server, positions, volume,
entry/SL/TP, journal, raw response.

## Isi paket

```
status_agent/
  __init__.py
  agent.py
  README_WINDOWS.md
tests/
  test_status_agent.py   (opsional, untuk verifikasi lokal)
```

## Instalasi (PowerShell)

```powershell
# 1. Ekstrak ZIP, lalu salin folder status_agent ke lokasi pemasangan:
Copy-Item -Recurse .\status_agent C:\trading-os\status_agent

# 2. Set secret (nilai yang SAMA dengan secret backend; jangan pernah di-chat/log):
[Environment]::SetEnvironmentVariable("ENGINE_STATUS_AGENT_SECRET", "<tempel nilai secret>", "User")
$env:ENGINE_STATUS_AGENT_SECRET = [Environment]::GetEnvironmentVariable("ENGINE_STATUS_AGENT_SECRET","User")

# 3. Verifikasi variable ada TANPA menampilkan nilainya:
[bool]$env:ENGINE_STATUS_AGENT_SECRET   # harus True

# 4. Tes sekali jalan:
cd C:\trading-os
python -m status_agent.agent --once
# Harapan: push=200 engine=ONLINE phase=WAITING_SETUP reachable=True
# Exit code 0 = sukses, 1 = push gagal, 2 = secret belum di-set

# 5. Jalan terus (heartbeat tiap 15 detik):
python -m status_agent.agent
# Opsional: daftarkan sebagai service via Task Scheduler / NSSM agar auto-start.
```

## Konfigurasi opsional (env)

| Variable | Default | Keterangan |
|---|---|---|
| `STATUS_RELAY_URL` | `https://ai-trading-os.lovable.app` | Base URL relay backend (harus https) |
| `STATUS_AGENT_ID` | `vps-1` | Identitas agent |
| `STATUS_PUSH_INTERVAL_S` | `15` | Interval push, minimum 5 detik |

## Verifikasi end-to-end

1. `https://ai-trading-os.lovable.app/api/public/engine-status` → `status: ONLINE`,
   `heartbeat_age_ms` kecil.
2. Banner dashboard menampilkan `STATUS RELAY: ENGINE ONLINE · …`.
3. Hentikan agent > 2 menit → capture berikutnya (±5 menit) mengirim Telegram
   ENGINE OFFLINE; jalankan lagi → BACK ONLINE pada heartbeat pertama.

## Tes lokal (opsional)

```powershell
cd C:\trading-os
python -m pytest tests\test_status_agent.py   # atau: python -m unittest discover tests
```

## Rollback

Hentikan proses agent, hapus `C:\trading-os\status_agent\`, hapus user env var
`ENGINE_STATUS_AGENT_SECRET`. Engine Host, Shadow, risk, proxy market-data, dan
jalur order tidak tersentuh sama sekali.
