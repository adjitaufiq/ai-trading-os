# Run as Administrator. Copies the agent, runs ONE test push, and only if push=200 registers the auto-start task.
# Separate from Engine Host: no Engine Host restart, no trading change. Outbound HTTPS only.
param([string]$Root = "C:\trading-os\status-agent", [string]$TaskName = "ArenaStatusAgent")
$ErrorActionPreference = "Stop"
if (-not [Environment]::GetEnvironmentVariable("ENGINE_STATUS_AGENT_SECRET", "Machine")) { throw "Machine env ENGINE_STATUS_AGENT_SECRET missing (value not shown)" }
"Secret present (Machine): True"
New-Item -ItemType Directory -Force "$Root\logs" | Out-Null
Copy-Item "$PSScriptRoot\status_agent" $Root -Recurse -Force
Copy-Item "$PSScriptRoot\tests" $Root -Recurse -Force
Copy-Item "$PSScriptRoot\run-status-agent.ps1","$PSScriptRoot\uninstall-status-agent.ps1" $Root -Force
Set-Location $Root
python -m unittest tests.test_status_agent
if ($LASTEXITCODE -ne 0) { throw "Unit tests failed - task NOT installed" }
$env:ENGINE_STATUS_AGENT_SECRET = [Environment]::GetEnvironmentVariable("ENGINE_STATUS_AGENT_SECRET", "Machine")
python -m status_agent.agent --once
$rc = $LASTEXITCODE
Remove-Item Env:\ENGINE_STATUS_AGENT_SECRET
if ($rc -ne 0) { throw "Test push did not return 200 - task NOT installed. Check secret / network, then rerun." }
$a = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$Root\run-status-agent.ps1`" -Root `"$Root`""
$t = New-ScheduledTaskTrigger -AtStartup
$s = New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew
$p = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
Register-ScheduledTask -TaskName $TaskName -Action $a -Trigger $t -Settings $s -Principal $p -Force | Out-Null
Start-ScheduledTask -TaskName $TaskName
"Task $TaskName registered (AtStartup, SYSTEM, restart on failure) and started. Log: $Root\logs\status-agent.log"
