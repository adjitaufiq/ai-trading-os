# Run as Administrator. Stops and removes the auto-start task and agent files. Engine Host untouched.
param([string]$Root = "C:\trading-os\status-agent", [string]$TaskName = "ArenaStatusAgent", [switch]$KeepFiles)
Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
Get-CimInstance Win32_Process -Filter "Name='python.exe' OR Name='powershell.exe'" | Where-Object { $_.CommandLine -match "status_agent|run-status-agent" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
if (-not $KeepFiles) { Set-Location C:\; Remove-Item $Root -Recurse -Force -ErrorAction SilentlyContinue }
"Status agent stopped and removed. Relay goes OFFLINE after 120s; Engine Host / trading unaffected."
