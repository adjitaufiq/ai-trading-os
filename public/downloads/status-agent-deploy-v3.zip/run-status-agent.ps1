# Supervisor loop used by the scheduled task: runs the agent, restarts it 30s after any exit.
# Reads ENGINE_STATUS_AGENT_SECRET from the Machine environment; the value is never printed or logged.
param([string]$Root = "C:\trading-os\status-agent")
$log = Join-Path $Root "logs\status-agent.log"
New-Item -ItemType Directory -Force (Split-Path $log) | Out-Null
$env:ENGINE_STATUS_AGENT_SECRET = [Environment]::GetEnvironmentVariable("ENGINE_STATUS_AGENT_SECRET", "Machine")
Set-Location $Root
while ($true) {
  if ((Test-Path $log) -and (Get-Item $log).Length -gt 5MB) { Move-Item $log "$log.1" -Force }
  "$(Get-Date -Format s) supervisor: starting agent" | Add-Content $log
  python -m status_agent.agent *>> $log   # agent prints only time, push code, engine, phase, reachable
  "$(Get-Date -Format s) supervisor: agent exited code=$LASTEXITCODE, restart in 30s" | Add-Content $log
  Start-Sleep -Seconds 30
}
