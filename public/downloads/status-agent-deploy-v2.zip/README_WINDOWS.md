# Status Agent v2 — Windows auto-start (Task Scheduler)

Outbound-only heartbeat: reads 127.0.0.1:8090 (health + execution-status), keeps only allowlisted status fields,
HMAC-signs and POSTs to https://ai-trading-os.lovable.app/api/public/agent/engine-status every 15s.
Separate process from Engine Host. No inbound port, no tunnel, no order path, no Engine Host restart.

## Prerequisite
Machine env var ENGINE_STATUS_AGENT_SECRET (same value as backend). Check without showing it:
    [bool][Environment]::GetEnvironmentVariable("ENGINE_STATUS_AGENT_SECRET","Machine")   # True

## Install (PowerShell as Administrator)
    powershell -ExecutionPolicy Bypass -File .\install-status-agent.ps1
Order enforced by the script: copy -> unit tests -> ONE test push (must be push=200) -> only then register task
"ArenaStatusAgent" (At startup, SYSTEM, restart every 1 min on failure, no time limit) + supervisor loop that restarts
the agent 30s after any exit. If the test push fails, nothing is scheduled.

## Check
    Get-ScheduledTask ArenaStatusAgent | Select State           # Running
    Get-Content C:\trading-os\status-agent\logs\status-agent.log -Tail 5   # push=200 ... (no secret in log)
    https://ai-trading-os.lovable.app/api/public/engine-status   # status ONLINE, small heartbeat_age_ms

## Stop / rollback
Pause:   Stop-ScheduledTask ArenaStatusAgent ; Disable-ScheduledTask ArenaStatusAgent
Remove:  powershell -ExecutionPolicy Bypass -File C:\trading-os\status-agent\uninstall-status-agent.ps1
Relay shows OFFLINE after 120s (Telegram sends one OFFLINE alert). Engine Host and trading are not affected.
