# Copies proxy files only. Touches nothing else. Backs up any existing proxy files first.
param([string]$Target = "C:\trading-os\arena-full-source-deploy-bae9120")
$ErrorActionPreference = "Stop"
if (-not (Test-Path "$Target\vps")) { throw "Target vps folder not found: $Target\vps" }
$bk = "$Target\backup-md-proxy-$(Get-Date -Format yyyyMMdd-HHmmss)"
if (Test-Path "$Target\vps\md_proxy") { New-Item -ItemType Directory $bk | Out-Null; Copy-Item "$Target\vps\md_proxy" $bk -Recurse; "Backup: $bk" }
New-Item -ItemType Directory -Force "$Target\vps\md_proxy" | Out-Null
Copy-Item "$PSScriptRoot\vps\md_proxy\*.py" "$Target\vps\md_proxy\" -Force
Copy-Item "$PSScriptRoot\vps\tests\test_md_proxy*.py" "$Target\vps\tests\" -Force
Copy-Item "$PSScriptRoot\run-md-proxy.ps1","$PSScriptRoot\test-md-proxy-local.ps1","$PSScriptRoot\rollback-md-proxy.ps1" $Target -Force
Get-ChildItem "$Target\vps\md_proxy" | Select Name, Length
"Installed. Engine Host / gateway / demo exec untouched."
