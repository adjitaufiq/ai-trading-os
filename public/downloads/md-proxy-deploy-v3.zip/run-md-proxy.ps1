# Read-only market-data proxy on 127.0.0.1:8780 -> gateway 127.0.0.1:8765. Ctrl+C to stop.
# Env set here applies to THIS window only (not machine-wide; Engine Host unaffected).
Set-Location (Join-Path $PSScriptRoot "vps")
$env:MD_PROXY_PORT = "8780"
$env:MD_PROXY_UPSTREAM = "http://127.0.0.1:8765"
$env:MD_PROXY_ALLOWED_ORIGINS = "https://ai-trading-os.lovable.app,https://id-preview--b7029c13-ae79-4d40-961b-542f2d4e9f08.lovable.app"
# Quick Tunnel phase: no Cloudflare Access. This exposes ONLY allowlisted XAUUSD/BTCUSD market data publicly.
# Default (unset) is cf_access, which requires MD_PROXY_CF_TEAM_DOMAIN + MD_PROXY_CF_AUD.
$env:MD_PROXY_ACCESS_MODE = "public_market_data"
# Engine analysis view (read-only, sanitized: account=null, trades=[]). Set "off" to disable without uninstalling.
$env:MD_PROXY_ENGINE_UPSTREAM = "http://127.0.0.1:8090"
$env:MD_PROXY_ENGINE_VIEW = "on"
python -m md_proxy.proxy
