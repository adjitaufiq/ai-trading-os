# Run in a second window while run-md-proxy.ps1 is active. Sends only GET/OPTIONS + one POST that must be refused.
Set-Location (Join-Path $PSScriptRoot "vps")
python -m unittest tests.test_md_proxy tests.test_md_proxy_access tests.test_md_proxy_engine_view -v
if ($LASTEXITCODE -ne 0) { "UNIT TESTS FAILED - do NOT start the tunnel"; exit 1 }
$b = "http://127.0.0.1:8780"
$checks = @(
  @("GET","/v1/health","200"),
  @("GET","/v1/ticks/latest/XAUUSD","200"), @("GET","/v1/ticks/latest/BTCUSD","200"),
  @("GET","/v1/symbols/XAUUSD","200"),
  @("GET","/v1/bars/XAUUSD/M5?mode=pos&start=0&count=5","200"), @("GET","/v1/bars/BTCUSD/H1?mode=pos&start=0&count=5","200"),
  @("GET","/v1/ticks/latest/EURUSD","403"),
  @("GET","/v1/bars/XAUUSD/M1?mode=pos&start=0&count=5","400"),
  @("GET","/v1/bars/XAUUSD/M5?mode=pos&start=0&count=501","400"),
  @("GET","/v1/terminal","404"), @("GET","/v1/demo/account","404"), @("GET","/v1/engine/execution-status","404"),
  @("GET","/v1/engine/journal","404"), @("GET","/v1/engine/account","404"), @("GET","/v1/engine/demo","404"),
  @("GET","/v1/engine/events","404"), @("GET","/v1/engine/XAUUSD/account","404"),
  @("GET","/v1/engine/health","200"), @("GET","/v1/engine/snapshot","200"),
  @("GET","/v1/analysis/snr/XAUUSD","200"), @("GET","/v1/analysis/snr/EURUSD","403"),
  @("POST","/v1/demo/orders","405"), @("DELETE","/v1/health","405")
)
$fail = 0
foreach ($c in $checks) {
  $r = curl.exe -s -o NUL -w "%{http_code}" -X $c[0] ($b + $c[1])
  $ok = $r -eq $c[2]; if (-not $ok) { $fail++ }
  "{0}  {1} {2} -> {3} (expect {4})" -f ($(if ($ok) {"PASS"} else {"FAIL"})), $c[0], $c[1], $r, $c[2]
}
$o = curl.exe -s -o NUL -w "%{http_code}" -H "Origin: https://evil.example" "$b/v1/health"
if ($o -ne "403") { $fail++ }; "CORS foreign origin -> $o (expect 403)"
$snap = curl.exe -s "$b/v1/engine/snapshot"
if ($snap -match '"balance"|"equity"|"tradeId"|"login"') { $fail++; "FAIL snapshot contains account/journal fields" } else { "PASS snapshot has no account/journal fields" }
if ($fail) { "FAILED: $fail - do NOT start the tunnel"; exit 1 } else { "ALL PASS - Quick Tunnel to 127.0.0.1:8780 allowed" }
