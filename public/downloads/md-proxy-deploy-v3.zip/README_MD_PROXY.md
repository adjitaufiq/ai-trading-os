# Market-Data + Analysis Proxy v3 — Windows/VPS (proxy only)

Same proxy as v2 on 127.0.0.1:8780 (same Quick Tunnel, same URL), plus a sanitized READ-ONLY analysis view of the
local Engine Host so the dashboard can show indicators, Radar, market context and SNR.
Does NOT touch Engine Host, demo exec (8100), Shadow, arm, risk, Decision Gate, strategy or orders. No restart of Engine Host.

## Routes (GET/OPTIONS only, XAUUSD|BTCUSD)
Market data -> gateway 8765: /v1/health · /v1/ticks/latest/{sym} · /v1/symbols/{sym} · /v1/bars/{sym}/{M5|M15|H1|H4}?mode=pos&start&count
Analysis -> Engine Host 8090 (new): /v1/engine/health · /v1/engine/snapshot · /v1/analysis/snr/{sym}
- snapshot: per symbol only symbol/timestamp/health/slice/radar/live/last_m5_close; account ALWAYS null, trades ALWAYS [].
- health: operating_mode, execution_enabled, started_at, persistence, demo_execution, per-symbol state; build/shadow and
  free-text errors dropped.
- Upstream body not a valid engine-host-v1 envelope -> 502 (never passed through).
Everything else (account, journal, demo, execution-status, pipeline, shadow, readiness, monitoring, events/SSE, terminal,
orders, 8100) -> 404/405 before any upstream call.

## Install / start / test
    powershell -ExecutionPolicy Bypass -File .\install-md-proxy.ps1     # backs up current md_proxy first
    # stop the running proxy window (Ctrl+C), then:
    powershell -ExecutionPolicy Bypass -File .\run-md-proxy.ps1
    powershell -ExecutionPolicy Bypass -File .\test-md-proxy-local.ps1  # must print ALL PASS + "no account/journal fields"
The existing Quick Tunnel to 8780 keeps running; do not restart it (URL would change).

## Rollback
Fast: set MD_PROXY_ENGINE_VIEW = "off" in run-md-proxy.ps1, restart proxy only (analysis routes -> 404).
Full: Ctrl+C proxy, then rollback-md-proxy.ps1 (restores the v2 backup), start run-md-proxy.ps1 again.
Trading unaffected in every case.
