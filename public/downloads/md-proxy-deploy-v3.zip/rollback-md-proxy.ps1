# Stop the proxy window (Ctrl+C) first. Restores the newest backup made by install-md-proxy.ps1 (v2 = market data only).
# Faster option without reinstall: set $env:MD_PROXY_ENGINE_VIEW = "off" in run-md-proxy.ps1 and restart the proxy only.
param([string]$Target = "C:\trading-os\arena-full-source-deploy-bae9120")
$bk = Get-ChildItem $Target -Directory -Filter "backup-md-proxy-*" | Sort-Object Name -Descending | Select-Object -First 1
if (-not $bk) { throw "No backup found in $Target" }
Remove-Item "$Target\vps\md_proxy" -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item "$($bk.FullName)\md_proxy" "$Target\vps\" -Recurse
Remove-Item "$Target\vps\tests\test_md_proxy_engine_view.py" -Force -ErrorAction SilentlyContinue
"Restored from $($bk.Name). Start run-md-proxy.ps1 again (same tunnel keeps working). Engine Host / gateway / demo exec untouched."
